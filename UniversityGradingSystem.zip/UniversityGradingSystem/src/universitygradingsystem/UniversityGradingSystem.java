package universitygradingsystem;

public class UniversityGradingSystem {

    public static void main(String[] args) {
        System.out.println("Program Initialized");
    }
    
}
